import SwiftUI

/// Original pastel-gem theme derived from the color mood of the user's reference photo.
/// Public/store builds should use only original abstract assets unless image/trademark rights are secured.
struct PastelGemTheme {
    static let pearl = Color(hex: "F8F4F7")
    static let blush = Color(hex: "EFC5C8")
    static let pink = Color(hex: "EFA8B6")
    static let sky = Color(hex: "8CC9DF")
    static let butter = Color(hex: "EEDB87")
    static let lime = Color(hex: "B2A742")
    static let lilac = Color(hex: "CBC3E9")
    static let ink = Color(hex: "342C3B")

    static let keyboardBackgroundAsset = "PastelGemKeyboardBackground"
    static let keyAsset = "PastelGemKey"
    static let keyPressedAsset = "PastelGemKeyPressed"
}

private extension Color {
    init(hex: String) {
        let value = UInt64(hex, radix: 16) ?? 0
        self.init(
            .sRGB,
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255,
            opacity: 1
        )
    }
}
