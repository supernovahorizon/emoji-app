# Pastel Gem Keyboard Asset Kit

Start with `KATSEYE-PASTEL-THEME-DESIGN.md`.

Recommended public-safe assets: `Backgrounds/StoreSafeAbstract`, `AppIcons/AppIcon-GemEye-1024.png`, `Charms`, and `iOS/Assets.xcassets`.

For a personal local build, the two `Backgrounds/PersonalUsePhoto` images are prepared from the reference photo with readability overlays.
