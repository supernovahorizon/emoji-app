# Asset provenance and release safety

- The color palette was sampled/curated from the user-selected KATSEYE promotional photo.
- `Backgrounds/PersonalUsePhoto/*` are transformed derivatives of that external photo. Treat them as personal/prototype assets unless distribution rights are confirmed.
- `Backgrounds/StoreSafeAbstract/*`, `Buttons/*`, `Charms/*`, and `AppIcons/*` were newly created for this kit and do not reproduce an official KATSEYE logo or member likeness.
- `Reference/source-photo.url` records the source chosen by the user; the original source file is intentionally not bundled in this kit.
- "KATSEYE" may be protected as a brand/trademark. Do not imply endorsement or affiliation in a public release.
