# Grok Build Task — Integrate Pastel Gem / KATSEYE-Inspired Theme

Implement the theme defined in `KATSEYE-PASTEL-THEME-DESIGN.md` into the existing iOS keyboard repository.

## Required behavior

1. Read the existing repository instructions, `AGENTS.md`, agent trackers, and current design docs before changing code.
2. Preserve all existing privacy rules: no Full Access, no networking from the keyboard, no typed-text logging, no analytics, no unnecessary permissions.
3. Add the theme as a new selectable theme; do not remove or regress existing themes.
4. Use the original `PastelGemKeyboardBackground` asset as the normal/release-safe default.
5. The photo-derived backgrounds under `Backgrounds/PersonalUsePhoto/` are for a local personal build only. Do not add the source photo or photo-derived assets to a public/release target unless explicitly configured locally.
6. Integrate `PastelGemTheme.swift`, the asset catalog, and `PastelGemEmojiCombos.json` cleanly with the existing architecture rather than duplicating theme/catalog systems.
7. Add the insertable Unicode combo category. Do not attempt to pretend custom PNG/SVG charms are Unicode emoji.
8. Use the custom charms only as decorative/category/preview art in this task.
9. Add a companion-app theme preview and confirm the keyboard background, category states, normal keys, and pressed keys all look correct.
10. Keep the globe/next-keyboard and backspace controls always reachable.
11. Validate portrait and landscape, VoiceOver, Reduce Motion, and minimum 44 pt touch targets.
12. Run the repository's full validation suite.
13. Build and install the app to the already-connected physical iPhone after tests pass. Do not change signing identities or commit private signing data.
14. Create/update the agent progress files throughout the work.
15. Create a final implementation report under `docs/reports/` containing what changed, screenshots only if privacy-safe, validation commands/results, device deployment result, known issues, and exact commit hashes.
16. Commit each cohesive completed task using conventional commit messages and push the branch/changes after validation.
17. Finish with `git status --short` empty. The working tree must be clean.

## Suggested commit sequence

```text
feat(theme): add pastel gem design tokens and assets
feat(keyboard): add pastel gem theme and unicode combos
feat(app): add pastel gem theme preview
feat(accessibility): validate pastel gem keyboard states
docs: add pastel gem implementation report
```

Keep terminal/chat output short. Put detailed progress and validation evidence in the repository report instead.
