# Pastel Gem / KATSEYE-Inspired Keyboard Theme — Design & Integration Spec

**Status:** implementation-ready theme add-on  
**Target:** Supernova Emoji / custom iOS keyboard  
**Reference mood image:** user-selected KATSEYE promotional photo from OUT  
**Default public-safe theme ID:** `pastelGem`  

## 1. Design direction

The reference image has a soft studio background and six coordinated pastel looks: lime, powder blue, butter yellow, blush pink, lilac, and pearl/white. The theme turns those colors into a **pastel gemstone + sparkle** visual system: frosted glass keys, pearly backgrounds, small gem/eye motifs, bows, stars, and subtle chrome highlights.

The goal is **inspired by the mood, not a copy of KATSEYE branding**. No official KATSEYE logo, album artwork, member portraits, signatures, or merch graphics are recreated in the original/store-safe assets.

## 2. Two asset modes

### Personal-use photo mode

`Backgrounds/PersonalUsePhoto/` contains transformed keyboard backgrounds derived from the exact reference photo supplied by URL. These are useful for a personal device build.

- `keyboard-photo-soft-1170x780.png` — readable, lightly blurred photo version.
- `keyboard-photo-dreamy-1170x780.png` — heavier blur and stronger pastel veil.
- `keyboard-concept-mockup.png` — implementation visual reference.

**Do not assume these photo-derived files can ship in the App Store.** Before public distribution, obtain the necessary photo/likeness/trademark permissions or exclude them from the release target.

### Store-safe abstract mode

`Backgrounds/StoreSafeAbstract/` is completely original and uses only the extracted/curated color mood plus generic gem/sparkle shapes. This should be the default distributable version unless rights are confirmed.

## 3. Palette

| pearl | `#F8F4F7` |
| blush | `#EFC5C8` |
| pink | `#EFA8B6` |
| powderBlue | `#92BACE` |
| sky | `#8CC9DF` |
| butter | `#EEDB87` |
| lime | `#B2A742` |
| lilac | `#CBC3E9` |
| plum | `#6D486A` |
| cocoa | `#7B4E37` |
| ink | `#342C3B` |
| chrome | `#E5E6EE` |

Use `ink` for text/symbols over pale keys. Reserve `plum` for stronger emphasis. Avoid full-saturation neon colors so the actual Unicode emoji remain visually dominant.

## 4. Keyboard composition

```text
┌──────────────────────────────────────────────┐
│  gem / category chips — pearl frosted strip │
├──────────────────────────────────────────────┤
│  emoji grid — 7–8 columns depending width   │
│  translucent rounded keys over background   │
│                                              │
├──────────────────────────────────────────────┤
│  Globe          Space/Charm       Backspace │
└──────────────────────────────────────────────┘
```

### Key behavior

- Normal: translucent pearl (`key-default`).
- Pressed: pink → lilac (`key-pressed`).
- Selected category: sky → butter (`key-selected`).
- Corner radius: roughly 25% of key width.
- Border: 1 pt white at about 70–90% opacity.
- Minimum touch target remains 44×44 pt.
- Keep the photo/background visually quiet enough that emoji glyphs remain obvious.

## 5. Custom KATSEYE-style “emoji” plan

A custom keyboard **cannot invent new Unicode emoji characters**. `textDocumentProxy.insertText()` can insert real Unicode text, but the custom PNG/SVG charms are not system-wide emoji characters.

Use two layers:

1. **Insertable Unicode combos** — `iOS/Code/PastelGemEmojiCombos.json`. These work everywhere as text, e.g. `💎👁️✨`, `🎀💗✨`, `🎤⭐💫`.
2. **Original visual charms** — `Charms/`. Use these as category icons, theme decorations, companion-app stickers, preview art, or a future explicitly-designed sticker feature.

Do not add clipboard/image-paste behavior to the privacy-first keyboard MVP just to make the charms act like stickers. That would change the security/privacy design and should be handled as a separate feature decision.

## 6. Original charm set

- `gem-eye` — original decorative charm; use as category art, preview sticker, or button decoration.
- `sparkle-six` — original decorative charm; use as category art, preview sticker, or button decoration.
- `pastel-bow` — original decorative charm; use as category art, preview sticker, or button decoration.
- `heart-gem` — original decorative charm; use as category art, preview sticker, or button decoration.
- `mic-star` — original decorative charm; use as category art, preview sticker, or button decoration.
- `headphones` — original decorative charm; use as category art, preview sticker, or button decoration.
- `butterfly` — original decorative charm; use as category art, preview sticker, or button decoration.
- `prism-rainbow` — original decorative charm; use as category art, preview sticker, or button decoration.
- `charm-orbit` — original decorative charm; use as category art, preview sticker, or button decoration.
- `camera-heart` — original decorative charm; use as category art, preview sticker, or button decoration.
- `shooting-star` — original decorative charm; use as category art, preview sticker, or button decoration.
- `six-petal-flower` — original decorative charm; use as category art, preview sticker, or button decoration.

The `six-petal-flower` and six orbit gems intentionally hint at a six-part ensemble without depicting or identifying any member.

## 7. Home-screen icon kit

Three original 1024×1024 icon options are in `AppIcons/`:

- **GemEye** — recommended. A pastel cat-eye gemstone with six orbit gems.
- **PrismStar** — more playful, less literal.
- **RibbonGem** — soft bow + gemstone aesthetic.

The included `iOS/Assets.xcassets/AppIcon.appiconset` selects **GemEye** by default. Icons contain no text, faces, official marks, or album art and are therefore much safer for a future public build.

## 8. iOS integration

Copy/merge `iOS/Assets.xcassets` into the app/keyboard asset catalog and copy `iOS/Code/PastelGemTheme.swift` plus `PastelGemEmojiCombos.json` into the shared theme/catalog module.

Recommended theme model:

```swift
KeyboardTheme(
    id: "pastelGem",
    displayNameKey: "theme.pastelGem",
    style: .imageBackground("PastelGemKeyboardBackground")
)
```

For the keyboard extension, prefer SwiftUI-rendered rounded rectangles and gradients for keys when practical. The provided key PNGs/SVGs are references/fallbacks; code-rendered keys scale better and use less asset memory.

### Personal photo background build flag

Keep the photo version out of the normal release target. A safe pattern is:

```text
PERSONAL_PHOTO_THEME = YES   // Local.xcconfig only, gitignored
```

When false/absent, load `PastelGemKeyboardBackground` from the original abstract asset set.

## 9. Performance rules

The existing keyboard design prioritizes low memory and no Full Access. Preserve those rules:

- Downsample photo backgrounds to the actual keyboard pixel size.
- Decode at most one active background.
- Do not keep the 1200×1200 reference source in the extension bundle.
- No networking from the keyboard.
- No member-photo downloads at runtime.
- No typed-text logging.
- Continue to show the globe/next-keyboard button at all times.

## 10. Accessibility

- Add a 20–35% pale veil if the photo is used so emoji/key contrast stays strong.
- Selected category must differ by more than color alone (outline/scale/check treatment).
- Respect Reduce Motion.
- Keep VoiceOver names descriptive and generic: “Gem Eye theme,” “Butterfly category icon,” etc.
- The visual charms are decorative unless they perform an action; decorative instances should be hidden from accessibility.

## 11. Public-release / IP boundary

KATSEYE is an active commercial music group, and the supplied photo is third-party media. A personal themed build is different from publicly distributing an app that uses their name, official photographs, logos, likenesses, or implied endorsement.

For an App Store release, the safest default is:

- public name: **Pastel Gem** (or another original name);
- use the store-safe abstract backgrounds and original GemEye icon;
- do not ship the supplied photo unless rights are secured;
- do not reproduce the KATSEYE logo or individual member likenesses;
- do not describe the app as official or affiliated.

## 12. Files in this kit

```text
Backgrounds/
  PersonalUsePhoto/      transformed photo backgrounds + mockup
  StoreSafeAbstract/     original distributable pastel backgrounds
Buttons/
  PNG/                   1x/2x/3x key states
  SVG/                   scalable key references
Charms/
  PNG/                   256 + 512 px transparent charms
  SVG/                   vector originals
AppIcons/                three 1024 px icons + previews
iOS/
  Assets.xcassets/       drop-in asset catalog pieces
  Code/                  Swift theme tokens + Unicode combo catalog
Reference/
  palette.json
  source-photo.url
```

## 13. Agent implementation checklist

- [ ] Add `pastelGem` theme without replacing existing Cosmic themes.
- [ ] Use store-safe abstract background by default.
- [ ] Add personal photo theme only through a local/non-release configuration.
- [ ] Add theme preview in companion app.
- [ ] Add Unicode combo category to keyboard catalog.
- [ ] Use custom charms as UI art only for MVP.
- [ ] Validate 44 pt touch targets, VoiceOver, portrait/landscape.
- [ ] Confirm `RequestsOpenAccess = false` remains unchanged.
- [ ] Confirm no runtime network requests are introduced.
- [ ] Build/install to the connected iPhone after validation.
- [ ] Add implementation report to the repo.
- [ ] Commit every completed task, push changes, and finish with a clean tree.

## 14. Definition of done

The theme is done when the companion app can preview it, the keyboard can select/use it, emoji remain readable over both backgrounds, Unicode combos insert correctly, no privacy capabilities change, device build succeeds, all tests pass, the implementation report is committed, the branch is pushed, and `git status --short` is empty.
